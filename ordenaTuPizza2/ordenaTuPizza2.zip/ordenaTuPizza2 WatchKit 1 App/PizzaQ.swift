//
//  PizzaQ.swift
//  ordenaTuPizza2
//
//  Created by Mario Porras on 14/5/16.
//  Copyright © 2016 MAPC. All rights reserved.
//

import WatchKit

class PizzaQ: NSObject {
    
    var tam: String = ""
    var masa: String = ""
    
    init(t:String, m:String){
        tam = t
        masa = m
    }

}
