//
//  Tamano.swift
//  ordenaTuPizza2
//
//  Created by Mario Porras on 14/5/16.
//  Copyright © 2016 MAPC. All rights reserved.
//

import WatchKit

class Tamano: NSObject {
    var tam : String = ""
    
    init(t:String){
        tam = t
    }
}
